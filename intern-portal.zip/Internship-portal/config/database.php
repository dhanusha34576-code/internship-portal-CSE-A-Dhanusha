php
<?php

$host = "db01.dbhost.dev";
$username = "user_455bwhfxq";
$password = "p455bwhfxq";
$database = "db_455bwhfxq";

try {
    $conn = new PDO(
        "mysql:host=$host;dbname=$database;charset=utf8mb4",
        $username,
        $password
    );

    $conn->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    $conn->setAttribute(
        PDO::ATTR_DEFAULT_FETCH_MODE,
        PDO::FETCH_ASSOC
    );

}  catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    die("Database connection failed. Check the server error log.");
}

