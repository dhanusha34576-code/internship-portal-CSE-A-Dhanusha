CREATE DATABASE internship_portal;

USE internship_portal;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student','company','admin') NOT NULL
);

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    phone VARCHAR(20),
    college VARCHAR(150),
    skills TEXT,
    resume VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    company_name VARCHAR(150),
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE internships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    title VARCHAR(150),
    description TEXT,
    skills_required TEXT,
    location VARCHAR(100),
    duration VARCHAR(50),
    FOREIGN KEY (company_id) REFERENCES companies(id)
);
CREATE TABLE IF NOT EXISTS companies (
    company_id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(150) NOT NULL,
    email VARCHAR(100) NOT NULL,
    location VARCHAR(100),
    description TEXT
);
CREATE TABLE IF NOT EXISTS internships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    skills_required TEXT,
    location VARCHAR(100),
    duration VARCHAR(50)
);
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    internship_id INT NOT NULL,
    resume VARCHAR(255),
    status VARCHAR(30) DEFAULT 'Applied',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO companies (user_id, company_name, description)
VALUES
(1, 'TCS', 'IT services and software development'),
(2, 'Infosys', 'Software development and technology'),
(3, 'Wipro', 'IT consulting and digital services'),
(4, 'Zoho', 'Software products and web applications'),
(5, 'Accenture', 'Technology and consulting services');

INSERT INTO internships
(company_id, title, description, skills_required, location, duration)
VALUES
(1, 'PHP Developer Intern',
 'Learn PHP and MySQL web development',
 'PHP, MySQL, HTML, CSS',
 'Chennai', '3 Months'),

(2, 'Web Developer Intern',
 'Build websites using modern web technologies',
 'HTML, CSS, JavaScript',
 'Bangalore', '6 Months'),

(3, 'Software Developer Intern',
 'Work on software development projects',
 'Java, SQL, Programming',
 'Coimbatore', '3 Months'),

(4, 'Full Stack Developer Intern',
 'Develop frontend and backend applications',
 'PHP, JavaScript, MySQL',
 'Chennai', '6 Months'),

(5, 'Python Developer Intern',
 'Learn Python programming and database integration',
 'Python, SQL, Django',
 'Bangalore', '3 Months');


INSERT INTO password_resets
(user_id, token, expires_at)
VALUES
(1, 'reset_token_abc123', '2026-10-11 10:00:00'),
(2, 'reset_token_def456', '2026-10-11 11:00:00'),
(3, 'reset_token_ghi789', '2026-10-11 12:00:00'),
(4, 'reset_token_jkl012', '2026-10-11 13:00:00'),
(5, 'reset_token_mno345', '2026-10-11 14:00:00');



INSERT INTO table_name (id, name)
VALUES
(1, 'users'),
(2, 'students'),
(3, 'companies'),
(4, 'internships'),
(5, 'applications'),
(6, 'departments'),
(7, 'employees'),
(8, 'password_resets'),
(9, 'salaries'),
(10, 'leaves');
```