
<?php
session_start();

if (!isset($_SESSION['internships'])) {
    $_SESSION['internships'] = [
        [
            'title' => 'PHP Web Development Intern',
            'description' => 'Learn PHP and MySQL web development.',
            'skills' => 'PHP, MySQL, HTML, CSS',
            'location' => 'Chennai / Remote',
            'duration' => '3 Months',
            'stipend' => '5000'
        ],
        [
            'title' => 'Python Developer Intern',
            'description' => 'Learn Python and database development.',
            'skills' => 'Python, SQL, Git',
            'location' => 'Bangalore / Remote',
            'duration' => '3 Months',
            'stipend' => '6000'
        ],
        [
            'title' => 'Java Developer Intern',
            'description' => 'Learn Java programming and build software applications.',
            'skills' => 'Java, OOP, SQL',
            'location' => 'Chennai',
            'duration' => '3 Months',
            'stipend' => '7000'
        ],
        [
            'title' => 'Web Design Intern',
            'description' => 'Create responsive and attractive websites.',
            'skills' => 'HTML, CSS, JavaScript',
            'location' => 'Coimbatore / Remote',
            'duration' => '2 Months',
            'stipend' => '4000'
        ],
        [
            'title' => 'Data Analyst Intern',
            'description' => 'Learn data analysis and create reports from datasets.',
            'skills' => 'Python, Excel, SQL',
            'location' => 'Bangalore',
            'duration' => '3 Months',
            'stipend' => '8000'
        ],
        [
            'title' => 'UI/UX Designer Intern',
            'description' => 'Design user-friendly interfaces for web and mobile apps.',
            'skills' => 'Figma, UI Design, UX Research',
            'location' => 'Remote',
            'duration' => '3 Months',
            'stipend' => '6000'
        ],
        [
            'title' => 'Cybersecurity Intern',
            'description' => 'Learn security fundamentals and basic vulnerability assessment.',
            'skills' => 'Networking, Linux, Security Basics',
            'location' => 'Chennai / Remote',
            'duration' => '6 Months',
            'stipend' => '9000'
        ]

    ];
}

$message = '';
$isSuccess = false;

function clean($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $stipend = trim($_POST['stipend'] ?? '');

    if (
        $title === '' ||
        $description === '' ||
        $skills === '' ||
        $location === '' ||
        $duration === '' ||
        $stipend === ''
    ) {
        $message = 'Please fill in all fields.';
    } elseif (!is_numeric($stipend) || (float)$stipend < 0) {
        $message = 'Enter a valid stipend amount.';
    } else {
        $_SESSION['internships'][] = [
            'title' => $title,
            'description' => $description,
            'skills' => $skills,
            'location' => $location,
            'duration' => $duration,
            'stipend' => $stipend
        ];

        header('Location: add_internship.php?success=1');
        exit;
    }
}

if (isset($_GET['success'])) {
    $message = 'Internship added successfully!';
    $isSuccess = true;
}

$search = trim($_GET['search'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Internship - Internship Portal</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f9;
    color: #263445;
}

header {
    background: #192e50;
    color: white;
    text-align: center;
    padding: 28px 15px;
}

header h1 {
    font-size: 32px;
    margin: 0 0 10px;
}

header p {
    margin: 0;
}

nav {
    background: white;
    padding: 18px 12px;
    display: flex;
    justify-content: center;
    gap: 28px;
    flex-wrap: wrap;
    box-shadow: 0 2px 8px #00000012;
}

nav a {
    color: #205582;
    text-decoration: none;
    font-weight: bold;
}

nav a:hover {
    color: #e58b26;
}

.container {
    max-width: 1250px;
    margin: 30px auto;
    padding: 0 20px;
}

.panel {
    background: white;
    padding: 28px;
    margin-bottom: 28px;
    border-radius: 14px;
    box-shadow: 0 4px 16px #0000000d;
}

h2 {
    color: #205582;
    margin-top: 0;
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.field {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.full {
    grid-column: 1 / -1;
}

label {
    font-weight: bold;
}

input, textarea, select {
    width: 100%;
    padding: 13px;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    font-size: 15px;
    background: white;
}

textarea {
    min-height: 110px;
    resize: vertical;
}

input:focus, textarea:focus, select:focus {
    outline: 2px solid #9bc5ec;
    border-color: #245783;
}

button, .button {
    display: inline-block;
    border: none;
    background: #245783;
    color: white;
    padding: 13px 22px;
    border-radius: 7px;
    cursor: pointer;
    font-size: 15px;
    font-weight: bold;
    text-decoration: none;
    text-align: center;
}

button:hover, .button:hover {
    background: #173c60;
}

.message {
    padding: 14px;
    margin: 20px 0;
    border-radius: 8px;
    background: #fee2e2;
    color: #991b1b;
}

.message.success {
    background: #dcfce7;
    color: #166534;
}

.search-form {
    display: flex;
    gap: 12px;
    margin: 20px 0;
}

.search-form input {
    flex: 1;
}

.cards {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 24px;
}

.card {
    padding: 25px;
    background: white;
    border-radius: 12px;
    border-top: 4px solid #245783;
    box-shadow: 0 4px 15px #0000000d;
    overflow-wrap: anywhere;
}

.card h3 {
    color: #205582;
    margin-top: 0;
    font-size: 22px;
}

.detail {
    line-height: 1.6;
    margin: 13px 0;
}

.status {
    display: inline-block;
    padding: 7px 15px;
    border-radius: 20px;
    background: #dcfce7;
    color: #166534;
    font-weight: bold;
}

.empty {
    background: #f8fafc;
    padding: 20px;
    border-radius: 8px;
}

footer {
    background: #192e50;
    color: white;
    text-align: center;
    padding: 20px;
}

@media (max-width: 700px) {
    .form-grid, .cards {
        grid-template-columns: 1fr;
    }

    .full {
        grid-column: auto;
    }

    .search-form {
        flex-direction: column;
    }

    .panel {
        padding: 18px;
    }

    header h1 {
        font-size: 26px;
    }
}
</style>
</head>

<body>

<header>
    <h1>🎓 Internship Portal</h1>
    <p>Company Panel - Tech Solutions</p>
</header>

<nav>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="profile.php">🏢 Profile</a>
    <a href="add_internship.php">➕ Add Internship</a>
    <a href="internships.php">💼 My Internships</a>
    <a href="applicants.php">👥 Applicants</a>
    <a href="../logout.php">🚪 Logout</a>
</nav>

<main class="container">

    <section class="panel">
        <h2>➕ Add New Internship</h2>
        <p>Fill in the details to add an internship opportunity.</p>

        <?php if ($message !== ''): ?>
            <div class="message <?php echo $isSuccess ? 'success' : ''; ?>">
                <?php echo clean($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="add_internship.php">
            <div class="form-grid">

                <div class="field full">
                    <label for="title">Internship Title</label>
                    <input
                        type="text"
                        id="title"
                        name="title"
                        maxlength="150"
                        placeholder="PHP Web Development Intern"
                        required
                    >
                </div>

                <div class="field full">
                    <label for="description">Description</label>
                    <textarea
                        id="description"
                        name="description"
                        maxlength="2000"
                        placeholder="Describe the internship..."
                        required
                    ></textarea>
                </div>

                <div class="field">
                    <label for="skills">Required Skills</label>
                    <input
                        type="text"
                        id="skills"
                        name="skills"
                        placeholder="PHP, MySQL, HTML, CSS"
                        required
                    >
                </div>

                <div class="field">
                    <label for="location">Location</label>
                    <input
                        type="text"
                        id="location"
                        name="location"
                        placeholder="Chennai / Remote"
                        required
                    >
                </div>

                <div class="field">
                    <label for="duration">Duration</label>
                    <select id="duration" name="duration" required>
                        <option value="">Select Duration</option>
                        <option value="1 Month">1 Month</option>
                        <option value="2 Months">2 Months</option>
                        <option value="3 Months">3 Months</option>
                        <option value="6 Months">6 Months</option>
                        <option value="12 Months">12 Months</option>
                    </select>
                </div>

                <div class="field">
                    <label for="stipend">Monthly Stipend (₹)</label>
                    <input
                        type="number"
                        id="stipend"
                        name="stipend"
                        min="0"
                        step="0.01"
                        placeholder="5000"
                        required
                    >
                </div>

                <div class="field full">
                    <button type="submit">➕ Add Internship</button>
                </div>

            </div>
        </form>
    </section>

    <section class="panel">
        <h2>💼 My Internships</h2>
        <p>View and search internship opportunities.</p>

        <form method="GET" action="add_internship.php" class="search-form">
            <input
                type="search"
                name="search"
                value="<?php echo clean($search); ?>"
                placeholder="Search internship, skills or location..."
            >
            <button type="submit">🔍 Search</button>
            <a href="add_internship.php" class="button">Reset</a>
        </form>

        <div class="cards">
            <?php
            $found = false;

            foreach (array_reverse($_SESSION['internships']) as $item):
                $searchText = implode(' ', $item);

                if (
                    $search !== '' &&
                    stripos($searchText, $search) === false
                ) {
                    continue;
                }

                $found = true;
            ?>
                <article class="card">
                    <h3><?php echo clean($item['title']); ?></h3>

                    <p class="detail">
                        <strong>📝 Description:</strong><br>
                        <?php echo nl2br(clean($item['description'])); ?>
                    </p>

                    <p class="detail">
                        <strong>📍 Location:</strong>
                        <?php echo clean($item['location']); ?>
                    </p>

                    <p class="detail">
                        <strong>⏳ Duration:</strong>
                        <?php echo clean($item['duration']); ?>
                    </p>

                    <p class="detail">
                        <strong>🛠️ Skills:</strong>
                        <?php echo clean($item['skills']); ?>
                    </p>

                    <p class="detail">
                        <strong>💰 Monthly Stipend:</strong>
                        ₹<?php echo clean(number_format((float)$item['stipend'], 2)); ?>
                    </p>

                    <span class="status">Active</span>
                </article>
            <?php endforeach; ?>

            <?php if (!$found): ?>
                <div class="empty">
                    No internships found. Please try another search.
                </div>
            <?php endif; ?>
        </div>
    </section>

</main>

<footer>
    <p>© <?php echo date('Y'); ?> Internship Portal | All Rights Reserved</p>
</footer>

</body>
</html>
