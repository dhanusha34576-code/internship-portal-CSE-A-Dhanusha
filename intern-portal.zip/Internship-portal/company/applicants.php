<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "company";
}

$companyName = "Tech Solutions";
$message = "";

$applicants = [

    1 => [
        "name" => "Haseen R",
        "email" => "haseenrafi12@gmail.com",
        "college" => "ABC Engineering College",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "02-10-2026",
        "status" => "Under Review"
    ],

    2 => [
        "name" => "Geethavarshini R",
        "email" => "geethavarshini2711@gmail.com",
        "college" => "XYZ Engineering College",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "01-10-2026",
        "status" => "Shortlisted"
    ],

    3 => [
        "name" => "Abirami R",
        "email" => "abiramiravi1767@gmail.com",
        "college" => "Mahendra Engineering College",
        "internship" => "Python Developer Intern",
        "applied_date" => "30-09-2026",
        "status" => "Pending"
    ],

    4 => [
        "name" => "Dhanusha K",
        "email" => "dhanusha34576@gmail.com",
        "college" => "Mahendra College of Engineering",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "29-09-2026",
        "status" => "Under Review"
    ],

    5 => [
        "name" => "Dhanishka S",
        "email" => "dhanishkas28@gmail.com",
        "college" => "Kongu Engineering College",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "28-09-2026",
        "status" => "Shortlisted"
    ],

    6 => [
        "name" => "Vishal Kumar",
        "email" => "vishal@gmail.com",
        "college" => "Sri Krishna College",
        "internship" => "Web Development Intern",
        "applied_date" => "27-09-2026",
        "status" => "Selected"
    ],

    7 => [
        "name" => "Keerthana R",
        "email" => "keerthana@gmail.com",
        "college" => "PSG College of Technology",
        "internship" => "UI/UX Design Intern",
        "applied_date" => "26-09-2026",
        "status" => "Under Review"
    ],

    8 => [
        "name" => "Ajay Kumar",
        "email" => "ajay@gmail.com",
        "college" => "Coimbatore Institute of Technology",
        "internship" => "Cyber Security Intern",
        "applied_date" => "25-09-2026",
        "status" => "Rejected"
    ],

    9 => [
        "name" => "Divya M",
        "email" => "divya@gmail.com",
        "college" => "Kumaraguru College of Technology",
        "internship" => "Cloud Computing Intern",
        "applied_date" => "24-09-2026",
        "status" => "Shortlisted"
    ],

    10 => [
        "name" => "Kavin Raj",
        "email" => "kavinraj@gmail.com",
        "college" => "Coimbatore Engineering College",
        "internship" => "Full Stack Developer Intern",
        "applied_date" => "23-09-2026",
        "status" => "Pending"
    ],
];

$search = "";

if (isset($_GET["search"])) {

    $search = trim($_GET["search"]);

}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["applicant_id"]) && isset($_POST["action"])) {

        $applicantId = $_POST["applicant_id"];
        $action = $_POST["action"];

        if ($action == "shortlist") {

            $message = "Applicant has been shortlisted successfully.";

        } elseif ($action == "reject") {

            $message = "Applicant has been rejected.";

        } elseif ($action == "select") {

            $message = "Applicant has been selected successfully.";

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Company - Applicants</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f2f5f9;
}


/* Header */

header {
    background: #172B4D;
    color: white;
    text-align: center;
    padding: 25px;
}

header h1 {
    margin: 0;
}

header p {
    margin-bottom: 0;
}


/* Navigation */

nav {
    background: white;
    padding: 15px;
    text-align: center;
    box-shadow: 0 2px 6px #ccc;
}

nav a {
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
    margin: 0 10px;
}

nav a:hover {
    color: #000;
}

.container {
    width: 92%;
    max-width: 1200px;
    margin: 30px auto;
}

.title-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 3px 10px #ddd;
}

.title-box h2 {
    margin-top: 0;
    color: #1f4e79;
}

.search-form {
    display: flex;
    gap: 10px;
}

.search-form input {
    flex: 1;
    padding: 13px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

.search-form button {
    padding: 13px 22px;
    background: #1f4e79;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}

.message {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 14px;
    border-radius: 7px;
    margin-bottom: 20px;
    font-weight: bold;
}

.applicant-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.applicant-card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px #ddd;
}

.applicant-card h3 {
    color: #1f4e79;
    margin-top: 0;
}

.applicant-card p {
    margin: 10px 0;
    color: #444;
}

.status {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    font-weight: bold;
}

.pending {
    background: #fff3cd;
    color: #856404;
}

.review {
    background: #e3f2fd;
    color: #1565c0;
}

.shortlisted {
    background: #e8f5e9;
    color: #2e7d32;
}

.selected {
    background: #d1f2eb;
    color: #00695c;
}

.rejected {
    background: #ffebee;
    color: #c62828;
}

.action-form {
    margin-top: 18px;
}

.action-form button {
    padding: 9px 13px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
    margin-right: 5px;
    font-weight: bold;
}

.shortlist-btn {
    background: #2e7d32;
}

.reject-btn {
    background: #c62828;
}

.select-btn {
    background: #00695c;
}

.back {
    display: inline-block;
    margin-top: 25px;
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
}

@media (max-width: 800px) {

    .applicant-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 500px) {

    .search-form {
        flex-direction: column;
    }

    .search-form button {
        width: 100%;
    }

}

</style>

</head>

<body>

<header>

    <h1>🎓 Internship Portal</h1>

    <p>
        Company Panel -
        <?php echo htmlspecialchars($companyName); ?>
    </p>

</header>

<nav>

    <a href="dashboard.php">
        🏠 Dashboard
    </a>

    <a href="profile.php">
        🏢 Profile
    </a>

    <a href="add_internship.php">
        ➕ Add Internship
    </a>

    <a href="internships.php">
        💼 My Internships
    </a>

    <a href="applicants.php">
        👥 Applicants
    </a>

    <a href="../logout.php">
        🚪 Logout
    </a>

</nav>


<div class="container">

    <div class="title-box">

        <h2>👥 Internship Applicants</h2>

        <p>
            View and manage students who applied for your internships.
        </p>

        <form method="GET" class="search-form">

            <input
                type="text"
                name="search"
                placeholder="Search applicant, email, college or internship..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button type="submit">
                🔍 Search
            </button>

        </form>

    </div>

    <?php if ($message != "") { ?>

        <div class="message">

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php } ?>

    <div class="applicant-grid">

    <?php

    $found = false;

    foreach ($applicants as $id => $applicant) {

        if (
            $search == "" ||
            stripos($applicant["name"], $search) !== false ||
            stripos($applicant["email"], $search) !== false ||
            stripos($applicant["college"], $search) !== false ||
            stripos($applicant["internship"], $search) !== false
        ) {

            $found = true;

    ?>

        <div class="applicant-card">

            <h3>
                👤 <?php echo htmlspecialchars($applicant["name"]); ?>
            </h3>

            <p>
                <strong>Email:</strong>
                <?php echo htmlspecialchars($applicant["email"]); ?>
            </p>

            <p>
                <strong>College:</strong>
                <?php echo htmlspecialchars($applicant["college"]); ?>
            </p>

            <p>
                <strong>Internship:</strong>
                <?php echo htmlspecialchars($applicant["internship"]); ?>
            </p>

            <p>
                <strong>Applied Date:</strong>
                <?php echo htmlspecialchars($applicant["applied_date"]); ?>
            </p>

            <p>
                <strong>Status:</strong>

                <?php

                if ($applicant["status"] == "Pending") {
                    echo '<span class="status pending">Pending</span>';
                }

                elseif ($applicant["status"] == "Under Review") {
                    echo '<span class="status review">Under Review</span>';
                }

                elseif ($applicant["status"] == "Shortlisted") {
                    echo '<span class="status shortlisted">Shortlisted</span>';
                }

                elseif ($applicant["status"] == "Selected") {
                    echo '<span class="status selected">Selected</span>';
                }

                elseif ($applicant["status"] == "Rejected") {
                    echo '<span class="status rejected">Rejected</span>';
                }

                ?>

            </p>

            <form method="POST" class="action-form">

                <input
                    type="hidden"
                    name="applicant_id"
                    value="<?php echo $id; ?>"
                >

                <button
                    type="submit"
                    name="action"
                    value="shortlist"
                    class="shortlist-btn"
                >
                    Shortlist
                </button>

                <button
                    type="submit"
                    name="action"
                    value="select"
                    class="select-btn"
                >
                    Select
                </button>

                <button
                    type="submit"
                    name="action"
                    value="reject"
                    class="reject-btn"
                >
                    Reject
                </button>

            </form>

        </div>

    <?php

        }

    }


    if (!$found) {

        echo "
        <div class='applicant-card'>
            <h3>No Applicants Found</h3>
            <p>Try another search keyword.</p>
        </div>
        ";

    }

    ?>

    </div>


    <a href="dashboard.php" class="back">
        ← Back to Company Dashboard
    </a>


</div>

</body>

</html>